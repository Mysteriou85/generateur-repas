package com.example.mealgenerator.model;

import java.util.List;

public record Ingredient(
        String id,
        String name,
        String category,
        List<String> flavors,
        String texture) {

    public Ingredient {
        flavors = flavors == null ? List.of() : List.copyOf(flavors);
    }
}
