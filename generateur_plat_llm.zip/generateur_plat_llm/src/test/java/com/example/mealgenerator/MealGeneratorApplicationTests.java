package com.example.mealgenerator;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.greaterThan;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class MealGeneratorApplicationTests {

    @Autowired
    private MockMvc mvc;

    @Test
    void listsIngredientsAndCookingMethodsFromJson() throws Exception {
        mvc.perform(get("/api/ingredients"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", greaterThan(0)));
        mvc.perform(get("/api/cooking-methods/grill"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.adjective").value("Grilled"));
    }

    @Test
    void generatesMealDescriptionViaPost() throws Exception {
        mvc.perform(post("/api/meals/description")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"ingredients\":[\"garlic\",\"chicken\",\"Lemon\"],\"cookingMethod\":\"roast\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Roasted Chicken with Garlic and Lemon"))
                .andExpect(jsonPath("$.description", containsString("prepared by roasting")))
                .andExpect(jsonPath("$.estimatedMinutes").value(60));
    }

    @Test
    void generatesMealDescriptionViaGet() throws Exception {
        mvc.perform(get("/api/meals/description")
                        .param("ingredients", "tofu,broccoli")
                        .param("cookingMethod", "stir-frying"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Stir-fried Tofu with Broccoli"));
    }

    @Test
    void returnsNotFoundForUnknownIngredient() throws Exception {
        mvc.perform(post("/api/meals/description")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"ingredients\":[\"unicorn\"],\"cookingMethod\":\"bake\"}"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.detail", containsString("unicorn")));
    }

    @Test
    void returnsBadRequestForInvalidPayload() throws Exception {
        mvc.perform(post("/api/meals/description")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"ingredients\":[],\"cookingMethod\":\"\"}"))
                .andExpect(status().isBadRequest());
    }
}
