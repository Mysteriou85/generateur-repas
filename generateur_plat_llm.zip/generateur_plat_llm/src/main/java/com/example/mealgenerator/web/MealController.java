package com.example.mealgenerator.web;

import com.example.mealgenerator.model.MealDescription;
import com.example.mealgenerator.model.MealRequest;
import com.example.mealgenerator.service.MealDescriptionService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/meals")
public class MealController {

    private final MealDescriptionService service;

    public MealController(MealDescriptionService service) {
        this.service = service;
    }

    @PostMapping("/description")
    public MealDescription describe(@Valid @RequestBody MealRequest request) {
        return service.describe(request.ingredients(), request.cookingMethod());
    }

    @GetMapping("/description")
    public MealDescription describe(@RequestParam List<String> ingredients, @RequestParam String cookingMethod) {
        return service.describe(ingredients, cookingMethod);
    }
}
