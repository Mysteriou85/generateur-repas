package com.example.mealgenerator.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public record MealRequest(
        @NotEmpty(message = "at least one ingredient is required") List<@NotBlank String> ingredients,
        @NotBlank(message = "cookingMethod is required") String cookingMethod) {
}
