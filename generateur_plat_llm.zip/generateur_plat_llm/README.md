# Meal Generator

Spring Boot REST webservice that generates a meal description from a list of ingredients and a cooking method.
Ingredients and cooking methods are stored in JSON files:

- `src/main/resources/data/ingredients.json`
- `src/main/resources/data/cooking-methods.json`

To use external files instead, override `meal.data.ingredients` / `meal.data.cooking-methods`
(e.g. `--meal.data.ingredients=file:./my-ingredients.json`).

## Run

Requires Java 17+.

```
mvn spring-boot:run
```

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/ingredients` | List ingredients |
| GET | `/api/ingredients/{id}` | Get one ingredient (id or name) |
| GET | `/api/cooking-methods` | List cooking methods |
| GET | `/api/cooking-methods/{id}` | Get one cooking method (id or name) |
| POST | `/api/meals/description` | Generate a description from a JSON body |
| GET | `/api/meals/description?ingredients=a,b&cookingMethod=x` | Same, using query parameters |

Example:

```
curl -X POST http://localhost:8080/api/meals/description \
  -H "Content-Type: application/json" \
  -d '{"ingredients":["salmon","lemon","rosemary"],"cookingMethod":"grill"}'
```

Unknown ingredients or methods return `404`; invalid payloads return `400`.
