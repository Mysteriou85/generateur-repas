package com.example.mealgenerator.model;

public record CookingMethod(
        String id,
        String name,
        String adjective,
        String heat,
        String temperature,
        int durationMinutes,
        String resultDescription) {
}
