package com.example.mealgenerator.web;

import com.example.mealgenerator.model.CookingMethod;
import com.example.mealgenerator.model.Ingredient;
import com.example.mealgenerator.repository.JsonDataRepository;
import com.example.mealgenerator.service.ResourceNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CatalogController {

    private final JsonDataRepository repository;

    public CatalogController(JsonDataRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/ingredients")
    public List<Ingredient> ingredients() {
        return repository.findAllIngredients();
    }

    @GetMapping("/ingredients/{id}")
    public Ingredient ingredient(@PathVariable String id) {
        return repository.findIngredient(id)
                .orElseThrow(() -> new ResourceNotFoundException("Unknown ingredient: " + id));
    }

    @GetMapping("/cooking-methods")
    public List<CookingMethod> cookingMethods() {
        return repository.findAllCookingMethods();
    }

    @GetMapping("/cooking-methods/{id}")
    public CookingMethod cookingMethod(@PathVariable String id) {
        return repository.findCookingMethod(id)
                .orElseThrow(() -> new ResourceNotFoundException("Unknown cooking method: " + id));
    }
}
