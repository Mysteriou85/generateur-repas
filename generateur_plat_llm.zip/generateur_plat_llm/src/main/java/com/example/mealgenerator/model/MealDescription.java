package com.example.mealgenerator.model;

import java.util.List;

public record MealDescription(
        String name,
        String description,
        List<Ingredient> ingredients,
        CookingMethod cookingMethod,
        int estimatedMinutes) {
}
