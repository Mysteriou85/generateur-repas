package com.example.mealgenerator.repository;

import com.example.mealgenerator.model.CookingMethod;
import com.example.mealgenerator.model.Ingredient;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

/**
 * Loads ingredients and cooking methods from JSON files at startup.
 * Lookups match either the id or the name, case-insensitively.
 */
@Repository
public class JsonDataRepository {

    private final Map<String, Ingredient> ingredients;
    private final Map<String, CookingMethod> cookingMethods;

    public JsonDataRepository(ObjectMapper objectMapper,
                              @Value("${meal.data.ingredients}") Resource ingredientsFile,
                              @Value("${meal.data.cooking-methods}") Resource cookingMethodsFile) {
        this.ingredients = index(read(objectMapper, ingredientsFile, new TypeReference<>() { }), Ingredient::id);
        this.cookingMethods = index(read(objectMapper, cookingMethodsFile, new TypeReference<>() { }), CookingMethod::id);
    }

    public List<Ingredient> findAllIngredients() {
        return List.copyOf(ingredients.values());
    }

    public List<CookingMethod> findAllCookingMethods() {
        return List.copyOf(cookingMethods.values());
    }

    public Optional<Ingredient> findIngredient(String idOrName) {
        return find(ingredients, idOrName, Ingredient::name);
    }

    public Optional<CookingMethod> findCookingMethod(String idOrName) {
        return find(cookingMethods, idOrName, CookingMethod::name);
    }

    private static <T> Optional<T> find(Map<String, T> data, String idOrName, Function<T, String> nameOf) {
        if (idOrName == null) {
            return Optional.empty();
        }
        String key = normalize(idOrName);
        T byId = data.get(key);
        if (byId != null) {
            return Optional.of(byId);
        }
        return data.values().stream()
                .filter(item -> normalize(nameOf.apply(item)).equals(key))
                .findFirst();
    }

    private static <T> List<T> read(ObjectMapper mapper, Resource resource, TypeReference<List<T>> type) {
        try (InputStream in = resource.getInputStream()) {
            List<T> items = mapper.readValue(in, type);
            return items == null ? List.of() : items;
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to read data file " + resource.getDescription(), e);
        }
    }

    private static <T> Map<String, T> index(List<T> items, Function<T, String> idOf) {
        Map<String, T> map = new LinkedHashMap<>();
        for (T item : items) {
            String id = idOf.apply(item);
            if (id == null || id.isBlank()) {
                throw new IllegalStateException("Data entry without id: " + item);
            }
            if (map.putIfAbsent(normalize(id), item) != null) {
                throw new IllegalStateException("Duplicate id in data file: " + id);
            }
        }
        return Collections.unmodifiableMap(map);
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }
}
