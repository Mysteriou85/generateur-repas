package com.example.mealgenerator.service;

import com.example.mealgenerator.model.CookingMethod;
import com.example.mealgenerator.model.Ingredient;
import com.example.mealgenerator.model.MealDescription;
import com.example.mealgenerator.repository.JsonDataRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class MealDescriptionService {

    static final int PREP_MINUTES_PER_INGREDIENT = 5;

    private static final List<String> MAIN_CATEGORY_PRIORITY = List.of("protein", "vegetable", "starch");

    private static final Map<String, String> HEAT_STYLE = Map.of(
            "dry", "The dry heat",
            "moist", "The gentle moisture",
            "fat", "The hot fat",
            "combination", "The slow, covered cooking");

    private final JsonDataRepository repository;

    public MealDescriptionService(JsonDataRepository repository) {
        this.repository = repository;
    }

    public MealDescription describe(List<String> ingredientKeys, String cookingMethodKey) {
        if (ingredientKeys == null || ingredientKeys.isEmpty()) {
            throw new IllegalArgumentException("at least one ingredient is required");
        }
        CookingMethod method = repository.findCookingMethod(cookingMethodKey)
                .orElseThrow(() -> new ResourceNotFoundException("Unknown cooking method: " + cookingMethodKey));

        List<Ingredient> ingredients = resolveIngredients(ingredientKeys);
        Ingredient main = pickMainIngredient(ingredients);
        List<Ingredient> sides = ingredients.stream().filter(i -> i != main).toList();

        String name = buildName(method, main, sides);
        String description = buildDescription(method, main, sides, ingredients);
        int estimatedMinutes = method.durationMinutes() + PREP_MINUTES_PER_INGREDIENT * ingredients.size();

        return new MealDescription(name, description, ingredients, method, estimatedMinutes);
    }

    private List<Ingredient> resolveIngredients(List<String> keys) {
        List<String> unknown = new ArrayList<>();
        Set<Ingredient> resolved = new LinkedHashSet<>();
        for (String key : keys) {
            repository.findIngredient(key).ifPresentOrElse(resolved::add, () -> unknown.add(key));
        }
        if (!unknown.isEmpty()) {
            throw new ResourceNotFoundException("Unknown ingredient(s): " + String.join(", ", unknown));
        }
        return List.copyOf(resolved);
    }

    private static Ingredient pickMainIngredient(List<Ingredient> ingredients) {
        for (String category : MAIN_CATEGORY_PRIORITY) {
            for (Ingredient ingredient : ingredients) {
                if (category.equalsIgnoreCase(ingredient.category())) {
                    return ingredient;
                }
            }
        }
        return ingredients.get(0);
    }

    private static String buildName(CookingMethod method, Ingredient main, List<Ingredient> sides) {
        StringBuilder name = new StringBuilder(method.adjective()).append(' ').append(capitalize(main.name()));
        if (!sides.isEmpty()) {
            name.append(" with ").append(joinNatural(sides.stream().map(i -> capitalize(i.name())).toList()));
        }
        return name.toString();
    }

    private static String buildDescription(CookingMethod method, Ingredient main, List<Ingredient> sides,
                                           List<Ingredient> all) {
        StringBuilder text = new StringBuilder();
        text.append(capitalize(articleFor(main.texture()))).append(' ').append(main.texture()).append(' ')
                .append(main.name());
        if (!sides.isEmpty()) {
            text.append(", accompanied by ").append(joinNatural(sides.stream().map(Ingredient::name).toList()));
        }
        text.append(", prepared by ").append(method.name())
                .append(" over ").append(method.temperature())
                .append(" for about ").append(method.durationMinutes()).append(" minutes. ");

        text.append(HEAT_STYLE.getOrDefault(method.heat(), "The cooking"))
                .append(" gives the dish ").append(method.resultDescription()).append('.');

        List<String> flavors = all.stream()
                .flatMap(i -> i.flavors().stream())
                .filter(f -> !"neutral".equalsIgnoreCase(f))
                .distinct()
                .toList();
        if (!flavors.isEmpty()) {
            text.append(" Expect a balance of ").append(joinNatural(flavors)).append(" notes in every bite.");
        }
        return text.toString();
    }

    private static String articleFor(String word) {
        return !word.isEmpty() && "aeiouAEIOU".indexOf(word.charAt(0)) >= 0 ? "an" : "a";
    }

    static String joinNatural(List<String> items) {
        int size = items.size();
        if (size == 0) {
            return "";
        }
        if (size == 1) {
            return items.get(0);
        }
        return String.join(", ", items.subList(0, size - 1)) + " and " + items.get(size - 1);
    }

    private static String capitalize(String value) {
        if (value == null || value.isEmpty()) {
            return value;
        }
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }
}
